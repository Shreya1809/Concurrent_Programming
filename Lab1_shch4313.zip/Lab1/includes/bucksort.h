#ifndef BUCKSORT_H_
#define BUCKSORT_H_


void bucketsortMethod(vector<int> *inputArray, size_t numOfThreads);

#endif