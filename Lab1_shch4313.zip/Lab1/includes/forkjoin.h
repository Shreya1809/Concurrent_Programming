#ifndef FORKJOIN_H_
#define FORKJOIN_H_

#include <vector>

void forkJoinMethod(vector<int> *inputArray, int numOfThreads);

#endif