#LAB 0 
Implementation of Merge Sort to emulate sort -n
The Lab report is in doc folder

##INSTALLATION
1. Go to directory Lab0
2. $make -> to compile
3. $ make clean -> to clean

##USAGE
Syntax: ./mysort --name [sourcefile.txt] -o [outputfile.txt]
All of the options below are correct usage
go to bin directory
1. $ ./mysort --name
2. $ ./mysort input.txt 
3. $ ./mysort input.txt -o output.txt
To execute the bash scripts 
go to script directory
1. $ chmod +x bashcript.sh
2. $ ./bashcript.sh

##CONTRIBUTOR
Shreya Chakraborty

##LICENSE

