#!/bin/bash
DOC_PATH="/home/shreya1809/Concurrent_Programming/Lab0/doc"
#./bashscript.sh #&> $DOC_PATH/output.txt
./bashscript.sh &> $DOC_PATH/output.txt